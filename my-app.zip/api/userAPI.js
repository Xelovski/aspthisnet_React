"use server"

const API_BASE="https://localhost:7025/api"

/*
Users
 */
export async function getUsers() {
    const res=await fetch(API_BASE);
    if (!res.ok){throw Error("Not succes for users")}
    return await res.json();
}
export async function getUser(id) {
    const res=await fetch(API_BASE+"/"+id);
    if (!res.ok){throw Error("Not succes for user")}
    return await  res.json()
}
export async function postUser(userdata) {//create  //name,email ,password
    if (userdata[0]==''||userdata[1]==''||userdata[2]==''||userdata==null){
        throw Error("EMPTY!")
    }
    let [name, email, password] = userdata.map(v => v ? String(v) : "");
    email=email.replace("%40","@")
    const res=await fetch(
        API_BASE,{method:"POST",
            headers:{"Content-Type":"application/json"},
            body: JSON.stringify({ name, email, password })
    })
    if(!res.ok){
        throw Error("Nepodarilo sa")
    }
    return await res.json();
}

/*
Store
 */
export async function getstore() {
    const res=await fetch("https://localhost:7025/api/storecontent");
    if (!res.ok){throw Error("Not succes for store")}
    return await res.json();
}
/*
Login
 */
export async function loginUser(userdata) {
    const q=userdata[0]
    const us = await getUsers()
    let res
    for (let i = 0; i < us.length; i++) {
        if(us[i]["emil"]==q){
            const log=API_BASE+"/login"
            res=await fetch(
                log,{method:"POST",
                    headers:{"Content-Type":"application/json"},
                    body:JSON.stringify({"publicId":us[i]["publicId"],"name":us[i]["name"],"password":String(userdata[1])})
    })}}
    //console.log(res)
    if(res==undefined){
        //console.log("Nepodarilo sa/ nenasiel")
        throw Error("Nepodarilo sa/ nenasiel")
    }
    else if(!res.ok){
        throw Error("Nepodarilo sa")
    }
    else{return res.json();}
}
export async function logedas() {
    const res=await fetch("https://localhost:7025/api/login");
    if (!res.ok){throw Error("Not succes for store")}
    return await res.json();
}
export async function logof() {
    const log=API_BASE+"/logof"
    const res=await fetch(
        log,{method:"POST",
            headers:{"Content-Type":"application/json"},
    })
    return await res.json()
}