
import { useEffect } from 'react'
import './App.css'
import { Foter } from './shared/footer'
import { Head } from './shared/header'
import { All } from './shared/all';




function App() {
  return(
    <>
      <Head/>
      <All/>
      <Foter/>
    </>

  )
}

export default App
