
export default function CreateU(){
    return <form action="CreateUserProcess">
        <h2>Creatin User</h2>
        <p><label>Name: <input type="text" name="name" placeholder="Sted"/> <small>Example:Stedmister01</small></label></p>
        <p><label>Emil: <input type="text" name="Email" placeholder="x@x.com"/> <small>Example:stef@somewhere.online</small></label></p>
        <p><label>Password: <input type="password" name="password" placeholder="1590"/></label></p>
        <input type="submit" name="a" defaultValue="Create" />
    </form>
}