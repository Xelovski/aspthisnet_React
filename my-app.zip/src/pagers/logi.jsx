import './idk.css'
import { useEffect, useState } from "react";
import { logedas } from "../../api/userAPI";
export default function Logi(){
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);
    useEffect(()=>{
        logedas()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);


    const options=[]
    if(users!=""){
        options.push(
            <div key={0}>
                <a href="Reset" className="butto4">Log of</a>
                <a href="Ch" className="butto4">Change</a>
            </div>
        )}
    else{
        options.push(
            <div key={1}>
            <a href="CreateU" className="butto4">Create new</a>
            </div>
        )
    }
    return(
        <>
        <form action="Loginprocess" method="get">
            <p><label>Emil: <input type="text" name="name" placeholder="x@x.com"/> <small>Example:stef@somewhere.online</small></label></p>
            <p><label>Password: <input type="password" name="pass" placeholder="Password"/> <small>Example:159078a</small></label></p>
            <input type="submit" name="q" defaultValue="Log in" />
        </form>
        <br />
        {options}
        </>
            
        
    )
}