import { useEffect, useState } from "react";
import { getorders, logedas } from "../../api/userAPI";
export default function Orde(){
    const [users,setUsers]=useState([]);const [loading,setLoading]=useState(true);const [error,setError]=useState(null);
    const [users1,setUsers1]=useState([]);const [loading1,setLoading1]=useState(true);const [error1,setError1]=useState(null);
    
    useEffect(()=>{
        getorders()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    useEffect(()=>{
        logedas()
        .then(setUsers1)
        .catch(err=>setError1(err.message))
        .finally(()=>setLoading1(false))
    },[]);
    const options = [];   
    let leng=users.length
    switch (true) {
        case loading:
            return <><p>Loading... what do you think bout red roses...?</p></>;
        case error: 
            return <><p>Mistake: {error}</p></>;
        default:
            //console.log(users1)
            if(users1=="a"){
                for (let i = 0; i < leng; i++) {
                options.push(<div key={i}>
                    <strong>{users[i].username} : {users[i].items}</strong> <br />
                    </div>)
            }
            }else{
                for (let i = 0; i < leng; i++) {
                    if(users1==users[i].username){
                        options.push(<div key={i}>
                            <strong>{users[i].items}</strong> <br />
                            </div>)
                }}
            }
            return <div>
            <h2>Orders</h2>
            <br />
            {options}
            </div>;
    }
}