export default function Orde(){
    const options = [];
    var ViewBag=[
        {"name":"Soup"},
        {"name":"The_picar"},
        {"name":"Keyboard"},
        {"name":"Guitar"},
        {"name":"9mil_(gun)"},
    ]
    let leng=ViewBag.length
    for (let i = 0; i < leng; i++) {
        options.push(<div key={i}>
            <strong>{ViewBag[i].name}</strong> <br />
            </div>)
    }
    return(<>
    Orders
    {options}
    </>)
}