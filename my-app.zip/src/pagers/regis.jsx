export default function Regis(){
    return(<>
        <form action="Register" method="post">
        <input type="text" name="name" defaultValue="" placeholder="Stef"/>
        <input type="password" name="passw" defaultValue="" placeholder="4440"/>
        <input type="email" name="emil" defaultValue="" placeholder="ja@dont.com"/>
        <input type="submit" name="q" value="registrrrrrr" />
        </form>
    </>)
}