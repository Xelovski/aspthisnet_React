import { useEffect, useState } from "react";
import { getUsers } from "../../api/userAPI";
export default function Updar(){
	const fullURL = window.location.href;
	const usableURL=fullURL.replace("http://localhost:5173/","")
	var q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    const w=q[1].replace("name=","")

	const [users,setUsers]=useState([]);const [loading,setLoading]=useState(true);const [error,setError]=useState(null);

	useEffect(()=>{
		getUsers()
		.then(setUsers)
		.catch(err=>setError(err.message))
		.finally(()=>setLoading(false))
	},[]);
	const options = []
	for (let i = 0; i < users.length; i++) {
		if(users[i]["name"]==w){
			options.push(
				users[i]["publicId"],
				users[i]["emil"],
				users[i]["name"]
			)   
		}
	}
    const ins={"PublicId":options[0],"Email":options[1],"Name":options[2]};const a=`${ins.PublicId}`;const b=`${ins.Email}`;const c=`${ins.Name}`;
	switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
    	return(<form action="idk" method="get">
	<input type="hidden" name="PublicId" defaultValue={a} />
	<input type="hidden" name="Name" defaultValue={c} />
	<p><label>Emil: <input type="text" name="Email" defaultValue={b}/> <small>Example:stef@somewhere.online</small></label></p>
	<input type="submit" value="CLICK" />
    </form>)
}}