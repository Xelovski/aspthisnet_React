import { useEffect, useState } from "react";
import { deleteU,getUsers } from "../../api/userAPI";

export default function UsrsD(){
    const fullURL = window.location.href;
	const usableURL=fullURL.replace("http://localhost:5173/","")
	var q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    const w=q[1].replace("=X","")
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);
    const [users1,setUsers1]=useState([]);
    const [loading1,setLoading1]=useState(true);
    const [error1,setError1]=useState(null);

    useEffect(()=>{
        getUsers()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    useEffect(()=>{
        deleteU(parseInt(w))
        .then(setUsers1)
        .catch(err=>setError1(err.message))
        .finally(()=>setLoading1(false))
    },[]);
    useEffect(() => {
        const timer = setTimeout(() => {
            window.location.replace("/Users")
        }, 1500);
        return () => clearTimeout(timer);
    }, []);
    //var ViewBag= await getUsers();
    //const leng=ViewBag.length;
    
    const options = [];
    //function CartAdd(a) {document.getElementById("Cart01").value += a + ",";}
    for (let i = 0; i < users.length; i++) {
        options.push(
        <tbody key={i}>
            <tr>
                <td>{users[i]["id"]}</td>
                <td><a href={"User/"+users[i]["id"]}>{users[i]["name"]}</a></td>
                <td>{users[i]["emil"]}</td>
                <td><a href={"Update?name="+users[i]["name"]}className="butto4">Change</a>
                </td>
                <td><form action="/UsersD"><input type="submit" name={users[i]["id"]} value="X" /></form></td>
            </tr>
        </tbody>
        )
    }
    return (<><a className="nav-link text-dark" href="CreateU">Create</a>
    <p>DELETING</p>
    <table className="table">    
    <thead>
        <tr>
            <td>Id</td>
            <td>Naame</td>
            <td>Email</td>
            <td>Edit</td>
            <td>delete</td> 
        </tr>
    </thead>
    {options}</table>
    <p>DELETING</p>
    </>
    )
}