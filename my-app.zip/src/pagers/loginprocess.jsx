import { loginUser } from "../../api/userAPI";
import { useEffect, useState } from "react";


export function LoginProcess(){
    const fullURL = window.location.href;
    const usableURL=fullURL.replace("http://localhost:5173/","")
    const q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    const w= q[1].split("&")
    let name=w[0].replace("name=","")//emil
    const pass=w[1].replace("pass=","")
    name=name.replace("%40","@")

    const [users,setUsers]=useState(false);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);

    
    useEffect(()=>{
        loginUser([name,pass])
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>{;setLoading(false)})
    },[]);

    useEffect(() => {
        const timer = setTimeout(() => {
            window.location.replace("/")
        }, 3000);
        return () => clearTimeout(timer);
    }, []);
    console.log(users)
    switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
        
        if(users){return <p>succes</p>}
        return <p>bad password/emil</p>

}}