import { useEffect, useState } from "react";
import { logof } from "../../api/userAPI";
export function Rese(){
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);
    useEffect(()=>{
        logof()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    useEffect(() => {
        const timer = setTimeout(() => {
            window.location.replace("/")
        }, 3000);
        return () => clearTimeout(timer);
    }, []);
    switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
    return <p>Loggin of</p>
}}