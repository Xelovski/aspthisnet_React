import { useEffect, useState } from "react";
import { getUsers } from "../../api/userAPI";
export default function Usr(){
    let fullURL = window.location.href;
    let usableURL=fullURL.replace("http://localhost:5173/","")
    var q = usableURL.split(usableURL.includes("?") ? "?" : "/");

    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);

    useEffect(()=>{
        getUsers()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    //var ViewBag= await getUsers();
    //const leng=ViewBag.length;
    
    const options = [];
    //function CartAdd(a) {document.getElementById("Cart01").value += a + ",";}
    for (let i = 0; i < users.length; i++) {
        if(users[i]["id"]==q[1]){
            options.push(
            <div key={i}>
                <p>id: {users[i]["id"]}</p>
                <h1>{users[i]["name"]}</h1>
                <h2>{users[i]["emil"]}</h2>
                <p>{users[i]["publicId"]}</p>
            </div>
            )   
        }
    }
        return (<>{options}
        </>
        
        )
    }