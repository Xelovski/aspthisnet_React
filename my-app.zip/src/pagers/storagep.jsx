"use client"
import { useEffect, useState } from "react";
import { getstore } from "../../api/userAPI";


export default function Storagep(){
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);
    
    useEffect(()=>{
        getstore()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    

    
    
    const options = [];
    switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
        //console.log(users)
        for (let i = 0; i < users.length; i++) {
            options.push(<p key={i}><label>{users[i].Name}<input type="submit" name={users[i].Name} value="Add" /></label></p>
            )
        }
        return (
        <div>
            <h1>Store Data</h1>
            <form action="StorepageProcess">
            <pre>{options}</pre>
            </form>
        </div>
    );
}}



function CartAdd(a) {document.getElementById("Cart01").value += a + ",";}
function Idk(){
    var ViewBag=["1","2","3"]
    let leng=ViewBag.length
    const options = [];
    for (let i = 0; i <= leng; i++) {
        options.push(<div key={i}>
            <label>{i}</label>
            <button type="button" onClick={CartAdd(`${i}`)}>add</button>
            <br />
        </div>
        )
    }
    return {options}
}