import { useEffect, useState } from "react";
import { putorder } from "../../api/userAPI";
export function Storagepprocess(){
    const fullURL = window.location.href;
    const usableURL=fullURL.replace("http://localhost:5173/","")
    const q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    const w= q[1].replace("=Add","")
    const [users,setUsers]=useState(false);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);

    
    useEffect(()=>{
        putorder(w)
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>{;setLoading(false)})
    },[]);

    useEffect(() => {
        const timer = setTimeout(() => {
            window.location.replace("/")
        }, 1500);
        return () => clearTimeout(timer);
    }, []);
    return <><p>Putting order</p></>
}