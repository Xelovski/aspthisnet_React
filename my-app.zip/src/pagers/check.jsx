export default function Check(){
    var ViewBag=["","",""]
    let leng=ViewBag.length
    const options = [];
    for (let i = 0; i <= leng; i++) {
        options.push(        
            <span className="inline" key={i}><strong>{i}@item.Name</strong>‎ ‎  x @item.Count
            <form >{/*asp-action="Checkout" method="post" style="display:inline;"*/}
            <input type="hidden" name="name" defaultValue="@item.Name" />{/**/}
            <input type="hidden" name="actionType" defaultValue="remove" />{/**/}
            <button type="submit">−</button> {/*"submit" @(item.Count <= 0 ? "disabled" : ""*/}
            </form>
            
            <form >{/*asp-action="Checkout" method="post" style="display:inline;"*/}
            <input type="hidden" name="name" defaultValue="@item.Name" />{/**/}
            <input type="hidden" name="actionType" defaultValue="add" />{/**/}
            <button type="submit">+</button>{/**/}
            </form>
            <br /><br /><br />
            </span>          
        );
    }
    
    return(<>
    <br />
    {options}
    <a href="Orders">
        Place order
        </a>
        </>
    )
}