export default function MakeUs(){
    return(
        <>
            <form action="MakeUser" method="post">
            <label asp-for="Name">Name</label>
            <input type="text" name="Name" />
            <br />
            <label asp-for="Email">emil</label>
            <input type="text" name="Email" />
            <input type="password" name="Password" placeholder="4440" />
            <input type="submit" value="CLICK" />
            </form>
        </>
    )
}