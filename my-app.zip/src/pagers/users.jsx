import { useEffect, useState } from "react";
import { getUsers } from "../../api/userAPI";

export default function Usrs(){
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);

    useEffect(()=>{
        getUsers()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    //var ViewBag= await getUsers();
    //const leng=ViewBag.length;
    
    const options = [];
    //function CartAdd(a) {document.getElementById("Cart01").value += a + ",";}
    for (let i = 0; i < users.length; i++) {
        options.push(
        <tbody key={i}>
            <tr>
                <td>{users[i]["id"]}</td>
                <td><a href={"User/"+users[i]["id"]}>{users[i]["name"]}</a></td>
                <td>{users[i]["emil"]}</td>
                <td><a href={"Update?name="+users[i]["name"]}className="butto4">Change</a>
                </td>
                <td><input type="checkbox" name={users[i]["id"]} id={users[i]["publicId"]} value={users[i]["publicId"]} /></td>
            </tr>
        </tbody>
        )
    }
    return (<><a className="nav-link text-dark" href="CreateU">Create</a>
    <table className="table">    
    <thead>
        <tr>
            <td>Id</td>
            <td>Naame</td>
            <td>Email</td>
            <td>Edit</td>
            <td>delete</td> 
        </tr>
    </thead>
    {options}</table></>
    )
}