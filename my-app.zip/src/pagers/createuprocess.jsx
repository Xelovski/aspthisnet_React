import {  postUser } from "../../api/userAPI";
import { useEffect, useState } from "react";


export function CreatUProcess(){
    const fullURL = window.location.href;
    const usableURL=fullURL.replace("http://localhost:5173/","")
    const q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    const w= q[1].split("&")
    const name=w[0].replace("name=","")
    let emil=w[1].replace("Email=","")
    const pass=w[2].replace("password=","")
    emil=emil.replace("%40","@")

    console.log(name,emil,pass)
    const [users,setUsers]=useState(false);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);

    
    useEffect(()=>{
        postUser([name,emil,pass])
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>{;setLoading(false)})
    },[]);

    useEffect(() => {
        const timer = setTimeout(() => {
            window.location.replace("/")
        }, 3000);
        return () => clearTimeout(timer);
    }, []);
    console.log(users)
    switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
        
        if(users){return <p>succes</p>}
        return <p>How...?</p>

}}