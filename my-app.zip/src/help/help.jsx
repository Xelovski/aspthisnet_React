"use server"
import { getUser } from "../../api/userAPI";

export function UserList({users}){
    let fullURL = window.location.href;
    let usableURL=fullURL.replace("http://localhost:7025/","")
    var q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    switch(q.length){
        case 2:
            return <p>{""+getUser(q[1]).name}</p>
             
        default:return(
        <ul>
            {users.map(u=>(
                <li key={u.id}>
                    {u.name}
                    <a href={"Pain/"+u.id}>more</a>
                </li>
            ))}
        </ul>
    )
    }
    
}