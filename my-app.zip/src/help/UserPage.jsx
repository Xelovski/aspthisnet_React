"use server"
import { useEffect, useState } from "react";
import { getUsers } from "../../api/userAPI";
import { UserList } from "./help";


export default function UserPage(){
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);

    useEffect(()=>{
        getUsers()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    
    switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
        return <UserList users={users} />;
}

}