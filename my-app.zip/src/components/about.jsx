import "./fot.css"
export function About(){
    return(
        <a href="#" className="x6">Bout</a>
    )

}