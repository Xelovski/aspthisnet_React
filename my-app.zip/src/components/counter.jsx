import { useState } from "react";
export function Counter(){
    const [count, setCount] = useState(0);
    function increase(){
        setCount(count + 1)
    }
    return <button onClick={increase}>You have clicked {count} times</button>
}