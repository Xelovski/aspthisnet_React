import { About } from "./about"
import { Contact } from "./contact"
import "./footer.css"
import { Links } from "./links"
export function Footer(){
    return(
        <div className="x5">
            <About/>
            <Links/>
            <Contact/>
        </div>
    )
}