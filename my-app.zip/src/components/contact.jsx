import "./fot.css"
export function Contact(){
    return(
        <a href="#" className="x6">Contacts</a>
    )
}