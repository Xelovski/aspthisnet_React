import { useEffect, useState } from "react"
import "./tabview.css"
import { FormExample } from "./formexample"
import { Counter } from "./counter"

function Info(){return <>
    <h1>Info</h1>
    <p>This site exist for no special reason...</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores quam illo provident, laudantium harum, corrupti culpa consequatur ducimus accusantium adipisci impedit maxime numquam ex earum voluptate non minima libero dolorum.</p>
</>
}
function Gallery(){return <>
    <h1>Gallery</h1>
    <img src="Wallpaper.png"alt="img01" className="inner"></img>
    <img src="fireW.gif" alt="fire" className="inner"></img>
</>
}
function Contact(){return <>
    <h1>Contact</h1>
    <div className="B">
            <div className="inner">
                <p>Phone numer:</p>
                <p>0950******</p>
            </div>
            <div className="inner">
                <p>insta:</p>
                <p>@formeLoL</p>
            </div>
        </div>
</>
}
function Other(){return<>
        <Counter/>
        <FormExample/>
    </>
}
export function TabView(){
    const [active,changeACT]=useState(0)
    useEffect(()=>{
        const interval=setInterval(()=>{
            console.log("...sus...");   
        },1000)
        return ()=>{
            clearInterval(interval);
            console.log("enlo me alive,timer stop")
        }
    },[])
    return <div className="M">
        <div className="B">
            <button onClick={()=>changeACT(1)}className="inner">Gallery</button>
            <button onClick={()=>changeACT(0)}className="inner">Info</button>
            <button onClick={()=>changeACT(2)}className="inner">Contact</button>
            <button onClick={()=>changeACT(3)}className="inner">Other</button>
        </div>
        <br />
        <p>{active==0&&<Info/>}{active==1&&<Gallery/>}{active==2&&<Contact/>}{active==3&&<Other/>}</p>
    </div>
}