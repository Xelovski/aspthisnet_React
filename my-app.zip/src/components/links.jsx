import "./fot.css"
export function Links(){
    return(
        <a href="#" className="x6">Linker</a>
    )
}