import "./logo.css"
export function Logo(){
    return(
        <img src="../../public/Wallpaper.png" className="x1"></img>
    )
}