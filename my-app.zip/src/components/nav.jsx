import { Logo } from "./logo";
import "./nav.css"
export function Nav(){
    return(
        <div className="x2">
            <Logo/>
            <div className="x3">
                <a href="#" className="x3">Main</a>
                <a href="#" className="x3">Oter</a>
            </div>
        </div>
    )
}