export function Main(){
    return(
        <div>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cum sequi adipisci hic neque, inventore eum repudiandae, deserunt veniam consequatur animi, aliquid obcaecati voluptatum perspiciatis corrupti delectus magnam deleniti voluptatem rem?
            </p>
            <p>404 not eaten</p>
        </div>
    )
}