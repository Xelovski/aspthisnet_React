import { useEffect, useState } from "react";

export default function Some(){
    const [users,setUsers]=useState([]);
    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then(res=>res.json())
        .then(data=>setUsers(data))
        .catch(err=>console.error("ERROR: ",err))
    },[]);
    
    return(
        <div style={{fontFamily:"Arial",padding:"20px"}}>
            <h1>Zoznam of users</h1>
            {users.length===0?(
                <p>nacitavam users...</p>
            ):(
                <ul>
                    {users.map(user=>(
                        <li key={user.id}>
                            <strong>{user.name}</strong>-{user.email}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    )
}