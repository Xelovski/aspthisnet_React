import { useState } from "react";

export function FormExample(){
    const [email,setEmail]=useState("")
    const isValid=email.includes('@')
    return <div>
        <input
        value={email}
        onChange={(e)=>setEmail(e.target.value)}
        placeholder="Give emil"
        />
        <br />
        <p>Given: "{email}" {isValid? "is valid":"isn't valid"}</p>
    </div>
}