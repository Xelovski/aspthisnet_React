
import UserPage from "../help/UserPage";
import { Checkout, Login, MakeUser, Orders, Register, Storepage, Update, User, Users, Logproc, Reset, CreateUser, CreateUserProcess, UsersDelete, StorepageProcess } from "./pagers";

export  function All(){
    let fullURL = window.location.href;
    let usableURL=fullURL.replace("http://localhost:5173/","")
    var q = usableURL.split(usableURL.includes("?") ? "?" : "/");
    switch(q[0]){
        case "StorepageProcess":return <StorepageProcess/>
        case "UsersD":return <UsersDelete/>
        case "CreateUserProcess": return <CreateUserProcess/>
        case "CreateU":return <CreateUser/>
        case "Reset":return <Reset/>
        //case "Ch":return<></>//change emil
        case "Checkout":return<Checkout/>
        case "Loginprocess":return<Logproc/>
        case "Login":return<Login/>
        case "MakeUser":return<MakeUser/>
        case "Orders":return<Orders/>
        case "Register":return<Register/>
        case "Rs":return<></>//reset pass
        case "Storepage":return<Storepage/>
        case "Update":return<Update/>
        case "User":return<User/>
        case "Users":return <Users/>
        case "Pain":return <UserPage/>//delete this if ya want
        default:return<h1>Welcome to suffering</h1>
    }
}