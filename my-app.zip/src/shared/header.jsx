import { useEffect, useState } from "react";
import { logedas } from "../../api/userAPI";
export function Head(){
    const [users,setUsers]=useState([]);
    const [loading,setLoading]=useState(true);
    const [error,setError]=useState(null);
    useEffect(()=>{
        logedas()
        .then(setUsers)
        .catch(err=>setError(err.message))
        .finally(()=>setLoading(false))
    },[]);
    let options="Login"
    let us=(<li className="nav-item"><a className="nav-link text-dark" href="">Users</a></li>)
    switch (true) {
    case loading:
        return <p>Loading... what do you think bout red roses...?</p>;
    case error:
        return <p>Mistake: {error}</p>;
    default:
        if (users!=""){
            if (users=="a")
            {us=(<li className="nav-item"><a className="nav-link text-dark" href="/Users">Users</a></li>)}
            options=users
        }
        return(
        <header className="up">
            <nav className="navbar navbar-expand-sm navbar-toggleable-sm navbar-light bg-white border-bottom box-shadow mb-3">
                <div className="container-fluid">
                    <a className="navbar-brand" href="/">WebApplication2</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                        <ul className="navbar-nav flex-grow-1">   
                            {us}
                            <li className="nav-item"><a className="nav-link text-dark" href="/Login">{options}</a></li> 
                            <li className="nav-item"><a className="nav-link text-dark" href="/Storepage">Store</a></li>
                            <li className="nav-item"><a className="nav-link text-dark" href="/Orders">Orders</a></li>                 
                        
                    </ul>
                    </div>
                </div>
            </nav>
        </header>
    )
}}