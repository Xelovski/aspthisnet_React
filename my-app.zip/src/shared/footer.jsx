export function Foter(){
    return(
        <footer className="border-top footer text-muted">
            <div className="container">
                &copy; 3004 - WebApplication2 - <a asp-area="" asp-controller="Home" asp-action="Privacy">Privacy</a>
            </div>
        </footer>
    )
}