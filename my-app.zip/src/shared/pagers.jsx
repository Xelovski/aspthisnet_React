
import Check from "../pagers/check"
import CreateU from "../pagers/createu"
import { CreatUProcess } from "../pagers/createuprocess"
import Logi from "../pagers/logi"
import { LoginProcess } from "../pagers/loginprocess"
import MakeUs from "../pagers/makeus"
import Orde from "../pagers/orde"
import Regis from "../pagers/regis"
import { Rese } from "../pagers/rese"
import Storagep from "../pagers/storagep"
import { Storagepprocess } from "../pagers/storagepprocess"
import Updar from "../pagers/updar"
import Usr from "../pagers/user"
import Usrs from "../pagers/users"
import UsrsD from "../pagers/usersD"

export function Checkout(){
    return<Check/>
}
export function Login(){
    return<Logi/>
}
export function MakeUser(){
    return<><MakeUs/></>
}
export function Orders(){
    return<><Orde/></>
}
export function Register(){
    return<><Regis/></>
}
export function Storepage(){
    return<><Storagep/></>
}
export function Update(){
    return<><Updar/></>
}
export function User(){
    return<><Usr/></>
}
export  function Users(){
    return <><Usrs/></>
}
export function Logproc(){
    return <><LoginProcess/></>
}
export function Reset(){
    return <><Rese/></>
}
export function CreateUser(){
    return <><CreateU/></>
}
export function CreateUserProcess(){
    return <><CreatUProcess/></>
}
export function UsersDelete(){
    return <><UsrsD/></>
}
export function StorepageProcess(){
    return <><Storagepprocess/></>
}