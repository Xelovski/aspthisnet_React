import { useState } from "react";

export default function MyForm3(){
    const [form,setForm]=useState({
        name:"",
        emil:"",
        check: false,
        state:"read"
    });
    function handleChange(e){
        setForm({
            ...form,
            [e.target.name]:e.target.value
        })
    }
    const country=["read","piton","rust"]
    function val(){
        if(!form.name.trim()||form.name==""){
            alert("wrong")
            return false
        }
        else if(!form.emil.trim()||!form.emil.includes("@")||form.emil=="@"){
            alert("wrong")
            return false
        }
        else if(form.check!=false&&form.check!=true){
            alert("wrong")
            return false
        }
        else if(!form.state.trim()||!country.includes(form.state)){
            alert("wrong")
            return false
        }
        else{return true}
    }
    function handelRes(){
        setForm({
            name:"",
            emil:"",
            check: false,
            state:"read"
        })
    }
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(val()){document.getElementById("si").textContent="THX! User "+form.name +" have been succesfully signed to "+form.state}
    };
    return <form onSubmit={handleSubmit}>
        <label htmlFor="name">full jmeno</label>
        <input type="text" name="name" id="name" value={form.name} onChange={handleChange} /><br />
        <label htmlFor="emil">full emil</label>
        <input type="text" name="emil" id="emil" value={form.emil} onChange={handleChange} /><br />
        <div className="row">
            <label htmlFor="state">space</label>
            <select name="state" id="state" value={form.state} onChange={handleChange} >
                <optgroup label="ez">
                    <option value="read">read</option>
                    <option value="piton">piton</option>
                </optgroup>
                <optgroup label="idk">
                    <option value="rust">rust</option>
                </optgroup>
                </select>            
        </div>
        <label htmlFor="check">news</label>
        <input type="checkbox" name="check" id="check" checked={form.check} onChange={(e)=>setForm({...form,check: e.target.checked})} /> <br />
        <button type="button" onClick={handelRes}>res</button>
        <button type="submit">give info</button>
        <p id="si">PLS sign in...</p>
    </form>
}
