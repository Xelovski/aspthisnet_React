import { useState } from "react";

export default function MyForm4(){
    const [form,setForm]=useState({
        name:"",
        emil:"",
        state:"1"
    });
    function handleChange(e){
        setForm({
            ...form,
            [e.target.name]:e.target.value
        })
    }
    const country=["1","2","3","4","5"]
    function val(){
        if(!form.name.trim()){
            alert("wrong")
            return false
        }
        else if(!form.emil.trim()||form.emil.length<10){
            alert("wrong")
            return false
        }
        else if(!form.state.trim()||!country.includes(form.state)){
            alert("wrong")
            return false
        }
        else{return true}
    }
    function handelRes(){
        setForm({
            name:"",
            emil:"",
            state:"1"
        })
        document.getElementById("emil").value=""
    }
    const handleSubmit=(e)=>{
        //console.log(document.getElementById("emil").value)
        e.preventDefault();
        if(val()){
            //alert("Jmeno: "+form.name +"\nRecenzia: "+form.emil+"\nRating: "+form.state);

            document.getElementById("re").innerHTML+="<br />Jmeno: "+form.name +" <i>Recenzia: "+form.emil+"</i> <b>Rating: "+form.state+"</b>"
            handelRes()}
    };
    return <form onSubmit={handleSubmit}>
        <label htmlFor="name">full jmeno</label>
        <input type="text" name="name" id="name" value={form.name} onChange={handleChange} /><br />
        <label htmlFor="emil">full emil</label>
        <textarea name="emil" id="emil" rows={5} onChange={(e)=>{setForm({
            ...form,
            [e.target.name]:document.getElementById("emil").value
        })}} >{form.emil}</textarea><br />
        <div className="row">
            <label htmlFor="state">rate</label>
            <select name="state" id="state" value={form.state} onChange={handleChange} >
                <optgroup label="pls dont">
                    <option value="1">1</option>
                    <option value="2">2</option>
                </optgroup>
                <optgroup label="yes">
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </optgroup>
                </select>            
        </div>
        <button type="button" onClick={handelRes}>res</button>
        <button type="submit">give info</button>
        <p id="re">Recenzie:</p>
    </form>
}
