import { useState } from "react";

export default function MyForm2(){
    const [form,setForm]=useState({
        kg:0,
        cm:0
    });
    function handleChange(e){
        setForm({
            ...form,
            [e.target.name]:e.target.value
        })
    }
    //const country=["svk","pl","rus"];
    function val(){
        if(isNaN(form.kg) && isNaN(parseFloat(form.kg))){
            alert("wrong")
            return false
        }
        else if(isNaN(form.cm) && isNaN(parseFloat(form.cm))){
            alert("wrong")
            return false
        }
        else{return true}
    }
    function handelRes(){
        setForm({
            kg:0,
            cm:0
        })
        document.getElementById("bmi").textContent="BMI:";
        document.getElementById("cat").textContent="cateGory:";
    }
    var bmi=0
    const handleSubmit=(e)=>{
        e.preventDefault();
        calc()
        if(val()){alert("vaha: "+form.kg+"kg"+"\nvyska: "+form.cm/100+"m"+"\nbmi: "+bmi);}
    };
    var cat="vpoho"
    function calc(){
        if(form.kg>0||form.cm>0){
            bmi=form.kg/((form.cm/100)*(form.cm/100))
            document.getElementById("bmi").textContent="BMI: "+bmi;
            if(bmi<18.5){cat="skinny"}
            else if(18.5<bmi&&bmi<24.9){cat="vpoho"}
            else if(24.9<bmi&&bmi<29.9){cat="almost bad"}
            else{cat="your MOM"}
            document.getElementById("cat").textContent="cateGory: "+cat
        }
        else{alert("give legit weight bro...")}
    }
    return <form onSubmit={handleSubmit}>
        <label htmlFor="kg">weight</label>
        <input type="number" min="0" max="10000" step="0.01" name="kg" id="kg" value={form.kg} onChange={handleChange} /><br />
        <label htmlFor="cm">cm vyska</label>
        <input type="number" min="0" max="700" step="0.01" name="cm" id="cm" value={form.cm} onChange={handleChange} /><br />
        <button type="button" onClick={handelRes}>res</button>
        <button type="button" onClick={calc}>pocitaj</button>
        <button type="submit">give info</button>
        <p id="bmi">BMI:</p>
        <p id="cat">category:</p>
    </form>
}
