import { useState } from "react";

export default function MyForm(){
    const [form,setForm]=useState({
        name:"",
        emil:"",
        check: false,
        state:"svk"
    });
    function handleChange(e){
        setForm({
            ...form,
            [e.target.name]:e.target.value
        })
    }
    const country=["svk","pl","rus"]
    function val(){
        if(!form.name.trim()){
            alert("wrong")
            return false
        }
        else if(!form.emil.trim()||!form.emil.includes("@")||!form.emil.includes(".")){
            alert("wrong")
            return false
        }
        else if(form.check!=false&&form.check!=true){
            alert("wrong")
            return false
        }
        else if(!form.state.trim()||!country.includes(form.state)){
            alert("wrong")
            return false
        }
        else{return true}
    }
    function handelRes(){
        setForm({
            name:"",
            emil:"",
            check: false,
            state:"svk"
        })
    }
    const handleSubmit=(e)=>{
        e.preventDefault();
        if(val()){alert("Jmeno: "+form.name +"\nemil: "+form.emil+"\naccepted to sell personal info: "+form.check+"\nKraj: "+form.state);}
    };
    return <form onSubmit={handleSubmit}>
        <label htmlFor="name">full jmeno</label>
        <input type="text" name="name" id="name" value={form.name} onChange={handleChange} /><br />
        <label htmlFor="emil">full emil</label>
        <input type="text" name="emil" id="emil" value={form.emil} onChange={handleChange} /><br />
        <label htmlFor="check">idk</label>
        <input type="checkbox" name="check" id="check" checked={form.check} onChange={(e)=>setForm({...form,check: e.target.checked})} /> <br />
        <div className="row">
            <label htmlFor="state">space</label>
            <select name="state" id="state" value={form.state} onChange={handleChange} >
                <optgroup label="zapad">
                    <option value="svk">svk</option>
                    <option value="pl">pl</option>
                </optgroup>
                <optgroup label="vychod">
                    <option value="rus">rus</option>
                </optgroup>
                </select>            
        </div>
        <button type="button" onClick={handelRes}>res</button>
        <button type="submit">give info</button>
    </form>
}
